// Put --- at the place of query
const WEBSITES = [
    'https://www.wallpaperflare.com/search?wallpaper=---&page=',
    'https://www.peakpx.com/en/search?q=---&page='
]

module.exports = { WEBSITES }