const mysql = require('mysql')

// mysql Connection
var con = mysql.createConnection({
    host: 'localhost',
    user: "u789069674_filmystation",
    database: "u789069674_filmystation",
    password: 'HoeJpmxE5$',
    port: "3306"
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Connected to mysql!");
});

module.exports = con